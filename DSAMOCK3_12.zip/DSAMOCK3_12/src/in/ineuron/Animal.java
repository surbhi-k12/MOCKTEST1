package in.ineuron;
/*
 * Create a superclass called Animal with a method makeSound() that prints the
 * sound made by the animal. Implement subclasses Dog, Cat, and Cow that inherit
 * from the Animal class. Implement the makeSound() method in each subclass to
 * print the sound made by a dog, cat, and cow, respectively.
 */

class Animals{
	
	public void makeSound() {
		System.out.println("Sound of Animal");
	}
	
}

class Dog extends Animal{
	public void makeSound() {
		System.out.println("Sound of Dog");
	}
}

class Cat extends Animal{
	public void makeSound() {
		System.out.println("Sound of Cat");
	}
}

class Cow extends Animal{
	public void makeSound() {
		System.out.println("Sound of Cow");
	}
}

class Animal{
	public static void main(String[] args) {
		Animals a=new Animals();
		a.makeSound();
		Dog g =new Dog();
		g.makeSound();
		Cow c=new Cow();
		c.makeSound();
		Cat cat=new Cat();
		cat.makeSound();
	}
}
